package com.example;

public class grocery {

    private String name;

    grocery(String n)
    {
        System.out.println(n);
          this.name=n;
    }

String getoffers()
{
      return this.name;
}

}

class stores extends grocery
{

private String storename;


    stores( String s)
    {
        super(s);
        System.out.println(s);
        this.storename=s;

    }

}


