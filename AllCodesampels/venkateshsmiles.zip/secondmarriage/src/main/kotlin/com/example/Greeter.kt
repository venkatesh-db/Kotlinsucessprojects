package com.example

class Greeter (private val name: String) {

    fun sayHello(){
       println("Hello $name")
    }

    companion object{
        fun greetStatic(){
            println("Hello Static")
        }
    }


}