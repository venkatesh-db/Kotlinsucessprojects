
package com.example.jaiganeshaminiproject.repository.redis

import com.example.jaiganeshaminiproject.model.redis.OrderStatus
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
interface OrderStatusRepository : CrudRepository<OrderStatus, Long>
