package com.example.jaiganeshaminiproject.model.redis


import org.springframework.data.annotation.Id
import org.springframework.data.redis.core.RedisHash
import org.springframework.data.redis.core.TimeToLive

@RedisHash("order_status")
data class OrderStatus(
    @Id
    val orderId: Long,

    var status: String,

    // auto-expire after 1 hour (3600 sec)
    @TimeToLive
    val ttl: Long = 3600
)
