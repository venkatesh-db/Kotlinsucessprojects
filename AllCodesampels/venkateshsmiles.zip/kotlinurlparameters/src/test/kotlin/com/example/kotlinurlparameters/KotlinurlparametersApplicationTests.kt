package com.example.kotlinurlparameters

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KotlinurlparametersApplicationTests {

    @Test
    fun contextLoads() {
    }

}
