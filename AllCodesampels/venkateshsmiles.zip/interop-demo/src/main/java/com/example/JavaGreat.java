package com.example;

public class JavaGreat {


       public String sayahello(){

           return "hellow ust 6th day";
       }

}
