
package com.example.jaiganesha.web

import com.example.jaiganesha.model.Book
import com.example.jaiganesha.repo.BookRepository
import com.fasterxml.jackson.databind.ObjectMapper
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.boot.test.mock.mockito.MockBean
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.*
import org.mockito.BDDMockito.*
import java.util.*

@WebMvcTest(BookController::class)
class BookControllerTest {

    @Autowired
    lateinit var mockMvc: MockMvc

    @MockBean
    lateinit var repo: BookRepository

    @Autowired
    lateinit var objectMapper: ObjectMapper

    // ---------- GET all books ----------
    @Test
    fun `GET all books`() {
        val books = listOf(Book(id = 1, title = "Kotlin", author = "Alice"))
        given(repo.findAll()).willReturn(books)

        mockMvc.perform(get("/api/books"))
            .andExpect(status().isOk)
            .andExpect(content().json(objectMapper.writeValueAsString(books)))
    }

    // ---------- GET book by id ----------
    @Test
    fun `GET book by id - found`() {
        val book = Book(id = 1, title = "Kotlin", author = "Alice")
        given(repo.findById(1)).willReturn(Optional.of(book))

        mockMvc.perform(get("/api/books/1"))
            .andExpect(status().isOk)
            .andExpect(content().json(objectMapper.writeValueAsString(book)))
    }

    @Test
    fun `GET book by id - not found`() {
        given(repo.findById(99)).willReturn(Optional.empty())

        mockMvc.perform(get("/api/books/99"))
            .andExpect(status().isNotFound())
    }

    // ---------- POST create book ----------
    @Test
    fun `POST create book`() {
        val book = Book(id = 1, title = "Spring", author = "Bob")
        given(repo.save(book)).willReturn(book)

        mockMvc.perform(
            post("/api/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(book))
        ).andExpect(status().isOk)
            .andExpect(content().json(objectMapper.writeValueAsString(book)))
    }

    // ---------- PUT update book ----------
    @Test
    fun `PUT update book - found`() {
        val existing = Book(id = 1, title = "Old", author = "Author1")
        val updated = Book(id = 1, title = "New", author = "Author2")
        given(repo.findById(1)).willReturn(Optional.of(existing))
        given(repo.save(existing)).willReturn(updated)

        mockMvc.perform(
            put("/api/books/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updated))
        ).andExpect(status().isOk)
            .andExpect(content().json(objectMapper.writeValueAsString(updated)))
    }

    @Test
    fun `PUT update book - not found`() {
        val updated = Book(id = 99, title = "New", author = "Author2")
        given(repo.findById(99)).willReturn(Optional.empty())

        mockMvc.perform(
            put("/api/books/99")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updated))
        ).andExpect(status().isNotFound())
    }

    // ---------- DELETE book ----------
    @Test
    fun `DELETE book - found`() {
        given(repo.existsById(1)).willReturn(true)
        willDoNothing().given(repo).deleteById(1)

        mockMvc.perform(delete("/api/books/1"))
            .andExpect(status().isNoContent())
    }

    @Test
    fun `DELETE book - not found`() {
        given(repo.existsById(99)).willReturn(false)

        mockMvc.perform(delete("/api/books/99"))
            .andExpect(status().isNotFound())
    }
}
