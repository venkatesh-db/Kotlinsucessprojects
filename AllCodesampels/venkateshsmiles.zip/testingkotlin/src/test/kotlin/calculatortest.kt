
package com.example

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

class calculatortest {

    private val calculatortes = Calculator()

    @Test
    fun testaddition() {
        val result=calculatortes.add(7,9)
        assertEquals(16,result,"7+9")
    }

    @Test
    fun testsubtraction() {
        val result=calculatortes.subtract(7,9)
        assertEquals(-2,result,"7-9")
    }

}