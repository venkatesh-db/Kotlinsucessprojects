package com.example

class Calculator {
    fun add(a: Int, b: Int): Int =a+b
    fun subtract(a: Int, b: Int): Int =a-b

}