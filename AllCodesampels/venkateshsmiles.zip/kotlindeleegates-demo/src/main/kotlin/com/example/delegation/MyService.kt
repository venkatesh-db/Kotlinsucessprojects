package com.example.delegation


class MyService( private val logger: Logger ): Logger by logger {

    fun dowork(id: String){

        log("starting with id $id")
        Thread.sleep(1000)
        log("finished with id $id")

    }

}

