package com.example.delegation

interface Logger {

    fun log(message: String)
}