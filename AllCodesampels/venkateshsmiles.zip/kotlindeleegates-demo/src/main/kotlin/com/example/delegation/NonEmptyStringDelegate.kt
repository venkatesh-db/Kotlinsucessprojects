package com.example.delegation

import kotlin.reflect.KProperty

class NonEmptyStringDelegate (private var value:String = ""){

    operator fun getValue(thisRef: Any?, property: KProperty<*>): String =value

    operator fun setValue(thisRef: Any?, property: KProperty<*>, newvalue: String) {

        if (newvalue.isBlank())
        {
            throw IllegalArgumentException("Value can't be empty")
        }
        this.value = newvalue
    }

}