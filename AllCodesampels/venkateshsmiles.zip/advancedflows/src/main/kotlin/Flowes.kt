package com.example

import jdk.jfr.internal.OldObjectSample.emit
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay


fun main()= runBlocking {


    val cold=flow {
        println("cold starts")
            println("looping emits")
            emit(7) // collect block
            println("cold end")
    } // regsiter here

    println("cold execute when i see colect")
    cold.collect{ println("venkatesh->it") }
    println("cold stopped")

    //  colect is executing the flow

    val state =MutableStateFlow(0)

    val uses=launch {
        println("uses launched")
        state.collect { println("state cuurebnet $it") }
    }

    println("before join")
    delay(1000)
    //uses.join()
    println("after join")
    state.value =state.value.inc()
    println("cancel me ")

    val usesa=launch {
        println("usesa launched")
        state.collect { println("state cuurebnet2 $it") }
    }

    uses.cancel()

   // multiple collector for MutableStateFlow
}