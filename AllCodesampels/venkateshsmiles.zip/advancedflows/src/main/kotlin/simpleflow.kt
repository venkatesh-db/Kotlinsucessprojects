import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

fun main()= runBlocking{

    println("parent starts")

   val kotlinflow= flow {

       println("flow on")
        emit("puniyam")

    }

    println("colector starts")
    kotlinflow.collect{ value->println("$value")}
    println("parent ends")

     // flow with operators

    (1..2).asFlow().map { it * it }.filter { it % 2 == 0 }.collect { println(it) }




}

