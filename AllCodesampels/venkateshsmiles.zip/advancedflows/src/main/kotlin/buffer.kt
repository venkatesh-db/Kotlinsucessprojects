

import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.*
import kotlin.system.measureTimeMillis

fun main()= runBlocking<Unit> {

    val time=  measureTimeMillis {
        simpleflow().buffer().collect { value -> delay(300);println("collcetd $value") }
            // producer wont wait for consumer
    }
}

fun simpleflow(): Flow<Int> = flow {

   for (i in 1..5) {
        delay(100)
        println("Emitting $i")
        emit(i)
    }
}