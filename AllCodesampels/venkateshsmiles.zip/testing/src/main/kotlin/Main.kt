package org.example


import kotlinx.coroutines.flow.*
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class FlowTestSample {

    fun numbersFlow(): Flow<Int> = flow {
        emit(1)
        emit(2)
        emit(3)
    }

    @Test
    fun testNumbersFlow() = runTest {
        val results = numbersFlow().toList()
        assertEquals(listOf(1, 2, 3), results)
    }
}

