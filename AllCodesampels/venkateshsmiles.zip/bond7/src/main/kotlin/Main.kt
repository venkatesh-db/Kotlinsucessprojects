package org.example

/*
import kotlinx.coroutines.*
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() =runBlocking{


    launch{
        delay(1000L)
        println("vishnu-1")
    }

    println("shiva-2")
}

 */

/*

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

fun main() = runBlocking {

    // Fake API #1: emit user IDs
    fun fetchUserIds(): Flow<Int> = flow {
        for (id in 1..5) {
            delay(100) // simulate network latency
            emit(id)
        }
    }

    // Fake API #2: fetch details for each user
    suspend fun fetchUserDetails(id: Int): String {
        delay(200) // slower API
        if (id == 3) throw RuntimeException("User $id not found!") // error simulation
        return "User$id: Name$id"
    }

    // Reactive flow pipeline
    fetchUserIds()
        .map { id ->
            try {
                fetchUserDetails(id)   // suspending call inside map
            } catch (e: Exception) {
                "Error(${e.message})" // recover gracefully

        }
        .filter { it.contains("User2").not() }   // filter out User2
        .onEach { println("Processing -> $it") } // side-effect logging
        .collect { println("Collected -> $it") } // final collection
}

*/
/*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel

fun main() = runBlocking {

    val channel = Channel<Int>()

    // Sender
    launch {
        for (x in 1..5) {
            channel.send(x)
            println("Sent: $x")
        }
        channel.close()
    }

    // Receiver
    launch {
        for (y in channel) {
            println("Received: $y")
        }
    }

    print("super")
}
*/




/*

fun main() = runBlocking {

    val channel = Channel<Int>(3)

    val prod =launch {

        for (i in 1..5) {

            println("producer $i")
            channel.send(i) // partial execcution

            println("producer innovatoon opy golang ")
          //  delay(500L)
            println("producer end $i")
        }
        channel.close()
    }

    val cons=launch {

        for (i in channel )
        {
            println("consumer $i")
            delay(500L)

        }
    }

    println("main waiting ")

    prod.join()
    println("Process1 exit")

    cons.join()

    println("Process2 exit")

    println("main exit")


}

*/

/*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.io.File


fun main()=runBlocking {

   val filepath="batmans.txt"

    val writejob=async (Dispatchers.IO)
    {
        println("smiling bonds ")
        File(filepath).writeText("Hello uset kotlin buddye!")
    }

    println("smiling kerla ")
    writejob.await()

    val readjob=async (Dispatchers.IO){
        File(filepath).readText()
    }

    println("smiling read ${readjob.await()}")
    println("smiling end ")
}

*/


import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel



/*

           launch  --> channel

      1. execution  -delay join wait

            flow --> internal channel

          1. execution -> no collector no flow execution

           2. communciation

 */

fun main()=runBlocking {

  val jobs=  launch{
        println("launch started")
    } // register

    jobs.join()

    println("main started")



}


/*
fun main() = runBlocking {

    val channel = Channel<Int>()

    // Producer 1
    launch {
        repeat(5) {
            println("Producer 1 ")
            channel.send(it)  // stop partial code executions

            println("Producer 1 sent: $it")
            delay(200)
            println("Producer 1 end ")
        }
    }

    // Producer 2
    launch {
        repeat(5) {
            println("Producer 2 ")
            channel.send(it + 100)   // stop partial code executions

            println("Producer 2 sent: ${it + 100}")
            delay(300)
            println("Producer 2 end ")
        }
    }

    // Consumer
    launch {
        println("consumer  ")
        for (x in channel) { // receieve
            println("Consumer received: $x")
        }
    }


    println("i dont sleep in venkatesh session")
    delay(2000)
    channel.close()
    println("Closed channel")

}
*/
