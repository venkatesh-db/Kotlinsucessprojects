

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking {

    val ordersChannel = Channel<Int>(Channel.UNLIMITED) // producer sends order IDs

    // Fan-out: multiple workers process concurrently
    repeat(3) { workerId ->
        launch {
            for (order in ordersChannel) {
                delay(100) // simulate work
                println("Worker $workerId processed order $order")
            }
        }
    }

    // Producer sends orders
    repeat(10) { ordersChannel.send(it) }

    ordersChannel.close() // important to close channel
}