package com.example.springcorroutines

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication


@SpringBootApplication
class SpringcorroutinesApplication

fun main(args: Array<String>) {
    runApplication<SpringcorroutinesApplication>(*args)
}


/*
curl -X POST http://localhost:9090/orders \
  -H "Content-Type: application/json" \
  -d '{
    "id": "123",
    "product": "Laptop",
    "quantity": 2
  }'

 */