package com.example.springcorroutines.repository

import com.example.springcorroutines.model.ProcessedOrder
import kotlinx.coroutines.delay
import org.springframework.stereotype.Repository

@Repository
class OrderRepository{

private val stroage=mutableListOf<ProcessedOrder>()

  suspend  fun save(processedOrder: ProcessedOrder) {
      delay(200)
        stroage.add(processedOrder)
        println("saved order $processedOrder")
    }

    fun getAll():List<ProcessedOrder> = stroage.toList()
}