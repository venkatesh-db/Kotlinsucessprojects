package com.example.springcorroutines.model

data class ProcessedOrder(
    val id: Int,
    val product: String,
    val quantity: Int,
    val processedAt: Long,
)
