package com.example.redisdatabase

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class RedisdatabaseApplicationTests {

    @Test
    fun contextLoads() {
    }

}
