package com.example.redisdatabase

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class RedisdatabaseApplication

fun main(args: Array<String>) {
    runApplication<RedisdatabaseApplication>(*args)
}
