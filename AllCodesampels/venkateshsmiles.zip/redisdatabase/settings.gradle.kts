rootProject.name = "redisdatabase"
