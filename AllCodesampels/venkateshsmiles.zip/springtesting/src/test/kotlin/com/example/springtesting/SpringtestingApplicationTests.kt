
package api

import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.get

@WebMvcTest(HelloController::class)
class HelloControllerTest(
    @Autowired val mockMvc: MockMvc
) {

    @Test
    fun `should return hello message`() {
        mockMvc.get("/hello") {
            param("name", "Coder")
        }
            .andExpect {
                status { isOk() }
                content { string("Hello, Coder!") }
            }
    }

    @Test
    fun `should return default hello when no name`() {
        mockMvc.get("/hello")
            .andExpect {
                status { isOk() }
                content { string("Hello, World!") }
            }
    }
}
