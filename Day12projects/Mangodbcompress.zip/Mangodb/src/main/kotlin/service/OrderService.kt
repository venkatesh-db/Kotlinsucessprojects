package com.example.mangodb.service

import com.example.mangodb.Order
import org.springframework.data.mongodb.core.aggregation.Aggregation.*

import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.stereotype.Service

@Service
class OrderService(private val mongoTemplate: MongoTemplate) {


    fun getTotalOrdersPerUser():List<Map<*,*>>{

        val aggregation = newAggregation(
            group("userId")
                .sum("quantity").`as`("totalQuantity")
        )

        val results: List<Map<*, *>> =
            mongoTemplate.aggregate(aggregation, "orders", Map::class.java).mappedResults

        return results
    }

fun getUserswithOrders(): List<Map<*,*>>{

    val aggregation = newAggregation(lookup("orders","_id","userId","orders"))

    return mongoTemplate.aggregate(aggregation, "users", Map::class.java).mappedResults
}

  fun getHighValueOrders(): List<Order>{

      val query=org.springframework.data.mongodb.core.query.Query().addCriteria(
          org.springframework.data.mongodb.core.query.Criteria.where("quantity").gt(5).and("price").gt(100.0))

          return mongoTemplate.find(query, Order::class.java)
  }

}