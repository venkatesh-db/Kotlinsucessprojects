package   com.example.mangodb.controller

import com.example.mangodb.service.OrderService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/orders")
class OrderController( private val orderService: OrderService) {

    @GetMapping("/total-per-user")
    fun totalOrdersPerUser()=
        orderService.getTotalOrdersPerUser()

    @GetMapping("/users-with-orders")
    fun userswithOrders()=
        orderService.getUserswithOrders()

    @GetMapping("/high-value")
    fun highvalueOrders()=
        orderService.getHighValueOrders()

}