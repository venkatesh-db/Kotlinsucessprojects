rootProject.name = "springcorroutines"
