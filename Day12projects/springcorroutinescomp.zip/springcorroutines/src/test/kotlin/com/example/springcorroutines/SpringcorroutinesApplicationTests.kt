package com.example.springcorroutines

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringcorroutinesApplicationTests {

    @Test
    fun contextLoads() {
    }

}
