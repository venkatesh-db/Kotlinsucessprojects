package com.example.springcorroutines.model

data class Order(
    val id:Int,
    val product:String ,
    val quantity:Int,
)
