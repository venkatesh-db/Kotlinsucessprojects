package com.example.unittestingbhai

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class UnittestingbhaiApplicationTests {

    @Test
    fun contextLoads() {
    }

}
