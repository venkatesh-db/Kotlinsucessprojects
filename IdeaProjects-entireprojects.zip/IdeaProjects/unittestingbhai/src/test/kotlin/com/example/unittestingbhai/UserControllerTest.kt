package com.example.unittestingbhai

import com.example.unittestingbhai.controller.UserController
import com.example.unittestingbhai.model.User
import com.example.unittestingbhai.service.UserService
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class UserControllerTest {

    private val userService = mockk<UserService>()
    private val controller = UserController(userService)

    @Test
    fun `should return user from controller`() {
        every { userService.getUser(1) } returns User(1, "MockUser1")

        val result = controller.getUser(1)
        assertEquals("MockUser1", result.name)
    }

    @Test
    fun `should return async user from controller`() = runTest {
        coEvery { userService.getUserAsync(2) } returns User(2, "MockAsyncUser2")

        val result = controller.getUserAsync(2)
        assertEquals("MockAsyncUser2", result.name)
    }
}
