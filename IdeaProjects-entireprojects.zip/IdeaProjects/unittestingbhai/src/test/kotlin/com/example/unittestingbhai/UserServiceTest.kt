package com.example.unittestingbhai

import com.example.unittestingbhai.service.UserService
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class UserServiceTest {

    private val userService = UserService()

    @Test
    fun `should return user synchronously`() {
        val user = userService.getUser(1)
        assertEquals("User1", user.name)
    }

    @Test
    fun `should return user asynchronously`() = runTest {
        val user = userService.getUserAsync(2)
        assertEquals("AsyncUser2", user.name)
    }
}
