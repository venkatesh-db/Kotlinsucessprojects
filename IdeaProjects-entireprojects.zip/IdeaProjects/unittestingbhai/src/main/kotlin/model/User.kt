package com.example.unittestingbhai.model


data class User(
    val id: Long,
    val name: String
)
