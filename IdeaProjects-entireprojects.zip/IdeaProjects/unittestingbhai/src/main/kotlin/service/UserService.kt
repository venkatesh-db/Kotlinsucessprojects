package  com.example.unittestingbhai.service

import com.example.unittestingbhai.model.User
import kotlinx.coroutines.delay
import org.springframework.stereotype.Service

@Service
class UserService {
    fun getUser(id: Long): User = User(id, "User$id")

    // Async coroutine example
    suspend fun getUserAsync(id: Long): User {
        delay(100) // simulate DB/network call
        return User(id, "AsyncUser$id")
    }
}
