package com.example.unittestingbhai.controller

import com.example.unittestingbhai.model.User
import com.example.unittestingbhai.service.UserService
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/users")
class UserController(private val userService: UserService) {

    @GetMapping("/{id}")
    fun getUser(@PathVariable id: Long): User =
        userService.getUser(id)

    @GetMapping("/async/{id}")
    suspend fun getUserAsync(@PathVariable id: Long): User =
        userService.getUserAsync(id)
}
