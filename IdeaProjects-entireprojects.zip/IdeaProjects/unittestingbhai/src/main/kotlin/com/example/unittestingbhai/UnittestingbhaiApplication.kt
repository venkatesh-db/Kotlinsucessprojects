package com.example.unittestingbhai

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class UnittestingbhaiApplication

fun main(args: Array<String>) {
    runApplication<UnittestingbhaiApplication>(*args)
}
