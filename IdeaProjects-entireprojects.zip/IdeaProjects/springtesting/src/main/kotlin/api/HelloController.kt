package api

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.bind.annotation.RequestParam


@RestController
class HelloController {

    @GetMapping("/")
    fun home() = "Welcome to Spring Boot!"

    @GetMapping("/hello")
    fun sayHello(@RequestParam(defaultValue = "World") name: String) =
        "Hello, $name!"
}
