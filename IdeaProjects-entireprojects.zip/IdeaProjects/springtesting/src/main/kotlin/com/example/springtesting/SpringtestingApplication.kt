package com.example.springtesting

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SpringtestingApplication

fun main(args: Array<String>) {
    runApplication<SpringtestingApplication>(*args)
}
