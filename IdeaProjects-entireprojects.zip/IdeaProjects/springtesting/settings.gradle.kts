rootProject.name = "springtesting"
