
/*
package com.example.springcorroutines.controller

import com.example.springcorroutines.service.OrderService
import org.springframework.web.bind.annotation.RequestBody
import com.example.springcorroutines.model.Order
import kotlinx.coroutines.GlobalScope
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import kotlinx.coroutines.*

@RestController
@RequestMapping("/orders")
class OrderController(private val service: OrderService) {


    @PostMapping
    suspend fun submitOrder(@RequestBody order: Order)
    {
        GlobalScope.launch {

            service.submitorder(order)
        }

    }
}
*/

package com.example.springcorroutines.controller

import com.example.springcorroutines.service.OrderService
import com.example.springcorroutines.model.Order
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/orders")
class OrderController(private val service: OrderService) {

    @PostMapping
    suspend fun submitOrder(@RequestBody order: Order): ResponseEntity<String> {
        service.submitorder(order)
        return ResponseEntity.ok("Order submitted successfully")
    }
}
