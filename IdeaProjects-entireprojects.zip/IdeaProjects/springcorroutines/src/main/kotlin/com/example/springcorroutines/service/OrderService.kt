package com.example.springcorroutines.service

import com.example.springcorroutines.repository.OrderRepository
import  com.example.springcorroutines.model.Order
import com.example.springcorroutines.model.ProcessedOrder
import jakarta.annotation.PostConstruct
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.Flow
import org.springframework.stereotype.Service
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

@Service
class OrderService(private val repo: OrderRepository)  {

    private val orderChannel= Channel<Order>(capacity=50)

    suspend fun submitorder(c:Order)
    {
        orderChannel.send(c)
        println("i am saying tata bye bye")
    }

    val processedOrderFlow: Flow<ProcessedOrder> = orderChannel.consumeAsFlow().map {
        order-> delay(100)
        println("9 smiling kotlin heros")
        ProcessedOrder(order.id,order.product,order.quantity,System.currentTimeMillis())
    }.onEach { repo.save(it) }.buffer(capacity=10).flowOn(Dispatchers.Default)

    @PostConstruct
     fun startConsumer(){
        CoroutineScope(Dispatchers.Default).launch {

            println("lulu mall owner party vsihnu")
            processedOrderFlow.collect()

        }

    }


}