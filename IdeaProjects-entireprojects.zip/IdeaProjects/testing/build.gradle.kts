plugins {
    kotlin("jvm") version "2.2.10"
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")

    // Coroutine Testing Utilities
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")

    // JUnit 5
    testImplementation("org.junit.jupiter:junit-jupiter-api:5.10.0")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.10.0")

    testImplementation("org.jetbrains.kotlin:kotlin-test:1.10.2")

   // testImplementation(kotlin("test"))


}

tasks.test {
    useJUnitPlatform()
}
kotlin {
    jvmToolchain(17)
}