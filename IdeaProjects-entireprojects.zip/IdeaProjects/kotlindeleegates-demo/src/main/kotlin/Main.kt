package com.example.delegation

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {

    println(" lord padmnabha temple !")

    val logger= ConsoleLogger()
    // ref       // object

    val service= MyService(logger) // loogert
    // ref        // object

    service.dowork("7") // passing object

    val user= User()

    println("${user.email}")

    println("seeting")
    user.name="lord shiva"

    try {
        user.username=""
    }catch(e: IllegalArgumentException){
        println(e.message)
    }

    user.name="murga"
}