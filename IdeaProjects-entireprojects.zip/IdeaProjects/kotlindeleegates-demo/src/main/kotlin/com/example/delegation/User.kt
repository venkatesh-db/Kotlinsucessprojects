package com.example.delegation

import kotlin.properties.Delegates

class User {

    var username :String by NonEmptyStringDelegate("guest")

val email:String by lazy{
    println("computing email")
    "bond@venkatesh.com"
}

    var name:String by Delegates.observable("unknown"){
        property, oldValue, newValue ->
        println("$oldValue -> $newValue")
    }


}