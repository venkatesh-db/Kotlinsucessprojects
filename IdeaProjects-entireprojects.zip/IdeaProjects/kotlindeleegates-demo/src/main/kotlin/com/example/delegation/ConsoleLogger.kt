package com.example.delegation

class ConsoleLogger:Logger {

    override fun log(message: String){

        println("[LOG] $message")
    }
}