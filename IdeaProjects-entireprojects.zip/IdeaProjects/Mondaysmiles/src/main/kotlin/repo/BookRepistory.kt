
package com.example.mondaysmiles.repo

import com.example.mondaysmiles.model.Book
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface BookRepistory:JpaRepository<Book, Long>