package com.example.mondaysmiles.model

import jakarta.persistence.*

@Entity
data class Book(
     @Id @GeneratedValue(strategy = GenerationType.AUTO)
     val id:Long?=null,
     var title:String?="",
     var author:String?=""
)