package com.example.mondaysmiles

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class MondaysmilesApplication


fun main(args: Array<String>) {
    runApplication<MondaysmilesApplication>(*args)
}


/*

curl -X POST http://localhost:8081/api/books \
     -H "Content-Type: application/json" \
     -d '{"title":"Kotlin in Action","author":"Dmitry Jemerov"}'
{"id":1,"title":"Kotlin in Action","author":"Dmitry Jemerov"}


curl -X PUT http://localhost:8081/api/books/1 \
     -H "Content-Type: application/json" \
     -d '{"title":"Updated Title","author":"Updated Author"}'

curl -X GET http://localhost:8080/api/books


 */