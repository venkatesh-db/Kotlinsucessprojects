package com.example.mondaysmiles

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MondaysmilesApplicationTests {

    @Test
    fun contextLoads() {
    }

}
