package com.example.mangodb

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class MangodbApplication

fun main(args: Array<String>) {
    runApplication<MangodbApplication>(*args)
}

/*

curl http://localhost:9090/orders/total-per-user
curl http://localhost:9090/orders/users-with-orders
curl http://localhost:9090/orders/high-value


curl http://localhost:9090/orders/high-value
. Create Order (POST)


. Create Order (POST)

1. Create Order (POST)

Ahh got it 👍 You don’t want to go through the API — you want to **insert records directly from the MongoDB shell** (`mongosh`).

Since you have a `User` model like this:

```kotlin
data class User(
    @Id
    val id: String? = null,
    val name: String,
    val email: String,
)
```

Spring Boot will map this to a MongoDB **collection: `users`**.

---

## 🔹 Steps in `mongosh`

1. Start the shell:

```bash
mongosh
```

2. Switch to your database (as per `application.properties` → `ordersdb`):

```javascript
use ordersdb
```

3. Insert users into the `users` collection:

```javascript
db.users.insertOne({
  name: "Alice",
  email: "alice@example.com"
})
```

4. Insert multiple users:

```javascript
db.users.insertMany([
  { name: "Bob", email: "bob@example.com" },
  { name: "Charlie", email: "charlie@example.com" },
  { name: "Diana", email: "diana@example.com" }
])
```

5. Verify data:

```javascript
db.users.find().pretty()
```

---

## 🔹 Insert Orders too (since you also have `Order` class)

```javascript
db.orders.insertOne({
  userId: "user123",
  productId: "prod456",
  quantity: 3,
  price: 499.99,
  orderDate: new Date()
})
```

Check:

```javascript
db.orders.find().pretty()
```

---

⚡ Now you can seed data directly in Mongo and then test your Spring Boot APIs (`/users`, `/orders/high-value`, etc.).

👉 Do you also want me to give you a **ready-made script** (`.js` file) you can run in `mongosh` to bulk insert dummy users + orders?




 */