
package com.example.mangodb.repos

import com.example.mangodb.Order
import com.example.mangodb.model.User
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository
import java.util.UUID

@Repository
interface UserRepository : MongoRepository<User, String>

@Repository
interface OrderRepository : MongoRepository<Order, String>{

    fun findByUserId(userId: String): List<Order>
}