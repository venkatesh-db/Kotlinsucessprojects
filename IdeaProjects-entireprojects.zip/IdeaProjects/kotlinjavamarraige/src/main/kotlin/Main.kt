package com.example
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {

    // executes java code

   val obj= JavaMigration()

   val ret= obj.sayahello()

    print(ret)


    // execution code

    val object1=grocery("zam zam");
    val rets=object1.getoffers()
    print(rets)

    val objct2= stores("ust time pass");
    val obj1:grocery = stores("ust time pass");

    obj1.getoffers()

    // Memory -  base +dervied
    // obj1 - acess base memory + base methods
    // obj1 -- acess derived method overrriddenn



}