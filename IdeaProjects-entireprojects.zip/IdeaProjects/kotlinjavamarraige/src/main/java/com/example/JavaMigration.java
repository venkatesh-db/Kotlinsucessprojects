package com.example;

public class JavaMigration {

    public String sayahello(){

        return "hellow ust 7th day";
    }

}


