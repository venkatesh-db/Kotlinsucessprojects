package com.example.javamarrykotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class JavamarrykotlinApplicationTests {

    @Test
    fun contextLoads() {
    }

}
