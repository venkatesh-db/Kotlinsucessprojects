package com.example.jaiganeshaminiproject.repository.mongo

import com.example.jaiganeshaminiproject.model.mongo.OrderItem
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface OrderItemRepository : MongoRepository<OrderItem, String>
