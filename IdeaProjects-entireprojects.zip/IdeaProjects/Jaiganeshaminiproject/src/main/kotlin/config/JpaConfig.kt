package com.example.jaiganeshaminiproject.config

import org.springframework.context.annotation.Configuration
import org.springframework.data.jpa.repository.config.EnableJpaRepositories

@Configuration
@EnableJpaRepositories(basePackages = ["com.example.jaiganeshaminiproject.repository.mysql"])
class JpaConfig
