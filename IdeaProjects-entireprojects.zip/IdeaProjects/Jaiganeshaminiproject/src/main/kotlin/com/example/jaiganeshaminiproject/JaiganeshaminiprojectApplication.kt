
package com.example.jaiganeshaminiproject

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class JaiganeshaminiprojectApplication

fun main(args: Array<String>) {
    runApplication<JaiganeshaminiprojectApplication>(*args)
}

/*


sudo systemctl start mysql
sudo systemctl start mongod
sudo systemctl start redis
# Kafka
cd kafka_2.13-3.7.1
bin/zookeeper-server-start.sh config/zookeeper.properties &
bin/kafka-server-start.sh config/server.properties &

bin/kafka-topics.sh --create --topic orders --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

# Create order
curl -X POST http://localhost:9090/api/orders \
-H "Content-Type: application/json" \
-d '{
  "customerName": "Alice",
  "totalAmount": 120.50,
  "items": [
    {"productName": "Laptop", "quantity": 1},
    {"productName": "Mouse", "quantity": 2}
  ]
}'

# Fetch order
curl http://localhost:9090/api/orders/1


curl -X POST http://localhost:9090/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "order": { "customerName": "Alice", "totalAmount": 250.75 },
    "items": [
      { "productName": "Shoes", "quantity": 1, "price": 200 },
      { "productName": "Socks", "quantity": 2, "price": 25.375 }
    ]
  }'

 */