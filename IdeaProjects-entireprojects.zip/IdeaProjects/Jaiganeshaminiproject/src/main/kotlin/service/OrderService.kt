
package  com.example.jaiganeshaminiproject.service

import com.example.jaiganeshaminiproject.model.mysql.Order
import com.example.jaiganeshaminiproject.model.mongo.OrderItem
import com.example.jaiganeshaminiproject.repository.mysql.OrderRepository
import com.example.jaiganeshaminiproject.repository.mongo.OrderItemRepository
import org.springframework.data.redis.core.RedisTemplate
import org.springframework.kafka.core.KafkaTemplate
import org.springframework.stereotype.Service

@Service
class OrderService(
    private val orderRepository: OrderRepository,
    private val orderItemRepository: OrderItemRepository,
    private val redisTemplate: RedisTemplate<String, Any>,
    private val kafkaTemplate: KafkaTemplate<String, Any>
) {
    fun placeOrder(order: Order, items: List<OrderItem>): Order {
        // Save in MySQL
        val savedOrder = orderRepository.save(order)

        // Save items in MongoDB
        items.forEach { orderItemRepository.save(it.copy(orderId = savedOrder.id)) }

        // Cache order in Redis
        redisTemplate.opsForValue().set("order:${savedOrder.id}", savedOrder)

        // Publish event to Kafka
        kafkaTemplate.send("orders-topic", savedOrder)

        return savedOrder
    }
}
