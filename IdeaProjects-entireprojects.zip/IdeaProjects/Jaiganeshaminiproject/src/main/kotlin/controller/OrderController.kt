
package com.example.jaiganeshaminiproject.controller

import com.example.jaiganeshaminiproject.model.mysql.Order
import com.example.jaiganeshaminiproject.model.mongo.OrderItem
import com.example.jaiganeshaminiproject.service.OrderService
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/orders")
class OrderController(private val orderService: OrderService) {

    @PostMapping
    fun createOrder(
        @RequestBody request: CreateOrderRequest
    ): Order = orderService.placeOrder(request.order, request.items)
}

data class CreateOrderRequest(
    val order: Order,
    val items: List<OrderItem>
)
