
package  com.example.jaiganeshaminiproject.model.mysql

import jakarta.persistence.*

@Entity
@Table(name = "orders")
data class Order(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    val customerName: String,
    val totalAmount: Double
)
