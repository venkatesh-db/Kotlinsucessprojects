
package  com.example.jaiganeshaminiproject.model.mongo

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "order_items")
data class OrderItem(
    @Id val id: String? = null,
    val orderId: Long,
    val productName: String,
    val quantity: Int,
    val price: Double
)
