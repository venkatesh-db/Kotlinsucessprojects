package com.example;

public class Main {

    public static void main(String[] args) {

    Greeter bond = new Greeter("ust smiles");

    bond.sayHello();

        Greeter.Companion.greetStatic();

        System.out.println("Hello World!");
    }
}
