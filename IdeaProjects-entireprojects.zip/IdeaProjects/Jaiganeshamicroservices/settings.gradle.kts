rootProject.name = "Jaiganeshamicroservices"
