package com.example.productcatalogservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ProductCatalogServiceApplication

fun main(args: Array<String>) {
    runApplication<ProductCatalogServiceApplication>(*args)
}

/*

curl -X POST http://localhost:9090/products \
-H "Content-Type: application/json" \
-d '{
  "name": "Laptop",
  "description": "High-end gaming laptop",
  "price": 1500.0
}'

curl -X GET http://localhost:9090/products/1

curl -X PUT "http://localhost:9090/products/1/price?price=1800.0"


 */