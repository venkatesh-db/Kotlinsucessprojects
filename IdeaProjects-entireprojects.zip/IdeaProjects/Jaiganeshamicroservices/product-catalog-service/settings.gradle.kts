rootProject.name = "product-catalog-service"
