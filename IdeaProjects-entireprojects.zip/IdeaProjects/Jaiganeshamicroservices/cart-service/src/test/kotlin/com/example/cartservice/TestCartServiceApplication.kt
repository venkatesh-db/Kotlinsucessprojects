package com.example.cartservice

import org.springframework.boot.fromApplication
import org.springframework.boot.with


fun main(args: Array<String>) {
    fromApplication<CartServiceApplication>().with(TestcontainersConfiguration::class).run(*args)
}
