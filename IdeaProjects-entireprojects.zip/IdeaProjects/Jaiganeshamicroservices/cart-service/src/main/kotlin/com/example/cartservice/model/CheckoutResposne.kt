package com.example.cartservice.model

data class CheckoutResposne(
    val lineTotal: List<CheckoutLine>,
    val total:Double,
)
