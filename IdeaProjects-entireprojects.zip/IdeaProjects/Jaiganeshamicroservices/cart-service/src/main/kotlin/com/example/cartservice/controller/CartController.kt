package com.example.cartservice.controller

import com.example.cartservice.model.CartItem
import com.example.cartservice.service.CartService
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController


@RestController
@RequestMapping("/cart")
class CartController(private val service: CartService) {

    @PostMapping("/{userId}/items")
    fun addItem(@PathVariable userid: String,@RequestBody item: CartItem): ResponseEntity<Void>{

        service.addItem(userid, item.productId,item.quantity)

        // Condition
        // Error hanlding
        // businnes logic in service

        return ResponseEntity.ok().build()
    }

    @GetMapping("/{userId}")
    fun viewCart(@PathVariable userid: String) = service.viewcart(userid)

    @PostMapping("/{userId}/checkout")
    fun checkout(@PathVariable userid:String) {

      service.checkout(userid)


    }
}