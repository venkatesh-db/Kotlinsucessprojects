package com.example.cartservice.model

data class CartItem(
    val productId: Long,
    val quantity: Int,
)
