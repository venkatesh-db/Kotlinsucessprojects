package com.example.cartservice.model

data class CartViewItem(
    val productId: Long,
    val quantity: Int,
    val cachedPrice: Double?,
)
