package com.example.cartservice.service

import com.example.cartservice.model.CartViewItem
import com.example.cartservice.model.CheckoutLine
import com.example.cartservice.model.CheckoutResposne
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.redis.core.HashOperations
import org.springframework.data.redis.core.RedisTemplate
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service
import org.springframework.web.client.RestTemplate

@Service
class CartService(
    private val redisTemplate: RedisTemplate<String, Any>,
    @Value("\${product.catalog.url}") private val catalogUrl: String
) {
    private val hashOps: HashOperations<String,String,Int>

        get()=redisTemplate.opsForHash()

    private fun cartKey(userid: String)="car:$userid"
    private fun priceKey(ProductId:Long)="product:price:${ProductId}"

    fun addItem(userid: String,ProductId: Long,qty:Int){


        /*

        The Redis key is a String (e.g., "cart:user123")

         The Hash field name is a String (e.g., "productId")

       The Hash field value is an Int (e.g., "2" = quantity)

        cart:user123 = {
    "prod101": 2,
    "prod202": 1,
    "prod303": 5
}
         */
        // tranformation
        val key=cartKey(userid)
        val field=ProductId.toString()
        val existing= hashOps.get(key,field)?:0
        hashOps.put(key,field,existing   +qty)

    }

    fun viewcart(userid: String):List<CartViewItem>{

       val key= cartKey(userid)
        val map=hashOps.entries(key)
        return map.map {  (prodIdstr,quantity)->

            val pid = prodIdstr.toLong()

            val cached = redisTemplate.opsForValue().get(priceKey(pid)) as? Double

            CartViewItem(productId = pid, quantity = quantity, cachedPrice = cached)
        }
    }

    // checkout: call product-catalog service for authoritative price for each item
    fun checkout(userId: String): CheckoutResposne {
        val key = cartKey(userId)
        val map = hashOps.entries(key)
        val rest = RestTemplate()
        val lines = mutableListOf<CheckoutLine>()
        var total = 0.0

        map.forEach { (prodIdStr, qty) ->
            val pid = prodIdStr.toLong()
            // call product catalog for real-time price
            val url = "$catalogUrl/products/$pid"
            val resp: ResponseEntity<Map<*, *>> = try {
                rest.getForEntity(url, Map::class.java)
            } catch (ex: Exception) {
                throw RuntimeException("Failed to contact product catalog for product $pid: ${ex.message}")
            }

            if (!resp.statusCode.is2xxSuccessful || resp.body == null) {
                throw RuntimeException("Product $pid not found in product catalog")
            }

            val body = resp.body!!
            val price = when (val p = body["price"]) {
                is Number -> p.toDouble()
                is String -> p.toDoubleOrNull() ?: throw RuntimeException("Invalid price for product $pid")
                else -> throw RuntimeException("Invalid price type for product $pid")
            }

            // update cached price so browsing gets refreshed
            redisTemplate.opsForValue().set(priceKey(pid), price)

            val lineTotal = price * qty
            lines.add(CheckoutLine(productId = pid, quantity = qty, price = price, lineTotal = lineTotal))
            total += lineTotal
        }

        // optional: clear cart on successful checkout
        redisTemplate.delete(key)
        return CheckoutResposne(lineTotal =lines ,total = total)
    }
}