package com.example.cartservice.model

data class CheckoutLine(
    val productId: Long,
    val quantity: Int,
    val price: Double,
    val lineTotal: Double

)
