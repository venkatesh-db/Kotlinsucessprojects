
package com.example.redisdatabase.controller

import com.example.redisdatabase.model.User
import com.example.redisdatabase.service.UserService
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/users")
class UserController(private val userService: UserService) {

    @PostMapping
    fun createUser(@RequestBody user: User): User = userService.saveUser(user)

    @GetMapping("/{id}")
    fun getUser(@PathVariable id: String): User? = userService.getUser(id)

    @GetMapping
    fun getUsers(): Iterable<User> = userService.getAllUsers()

    @DeleteMapping("/{id}")
    fun deleteUser(@PathVariable id: String) = userService.deleteUser(id)
}
