

package com.example.redisdatabase.service

import com.example.redisdatabase.model.User
import com.example.redisdatabase.repository.UserRepository
import org.springframework.stereotype.Service

@Service
class UserService(private val userRepository: UserRepository) {

    fun saveUser(user: User): User = userRepository.save(user)

    fun getUser(id: String): User? = userRepository.findById(id).orElse(null)

    fun getAllUsers(): Iterable<User> = userRepository.findAll()

    fun deleteUser(id: String) = userRepository.deleteById(id)
}
