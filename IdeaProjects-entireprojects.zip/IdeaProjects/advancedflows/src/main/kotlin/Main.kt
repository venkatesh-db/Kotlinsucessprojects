package com.example

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() =runBlocking{

    val jobs=launch{
        println("icecream1")
    }
    println("started")
   // jobs.join()

    delay(1000)
    println("nodia")

    coroutineScope {
        launch { println("milk") }
        launch { println("curd") }
    }

    val result  = async{
        println("eating in  hotel going to hosiptal")
        5000
    }

    val result2 = async{
        println("eating in  house going to temple")
        500
    }

   val sum= result.await() +result2.await()
    println("total colestrol"+sum)
    println("eating vesgtables")

    // async , launch , coroutineScope - differes ways of eexcution

}