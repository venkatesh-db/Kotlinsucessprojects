import kotlinx.coroutines.*
import kotlinx.coroutines.runBlocking


fun main()= runBlocking{

    println("parent starts")
coroutineScope {
    launch {
        println("child starts")
    }
}

    println("parent ends")

        }