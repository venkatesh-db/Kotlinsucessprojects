
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

fun main() =runBlocking {

    val jobs = launch {
        println("icecream1")
        delay(1000)
        println("icecream2")
    }
    delay(10)

    jobs.cancel()
    //jobs.join()

    withTimeout(400) {
        println("job timeout")
        delay(1000)
    }

   // jobs.cancelAndJoin()
    println("started")

}