
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() =runBlocking{


    val shared=MutableSharedFlow<Int>(replay=1)

   val c1=launch {
       println("shared c1")
       shared.collect{println("shared c1 collect ->$it")}
        println("end of shared c1")
   }

    delay(50)
    println("main emitting")

    shared.emit(1)
    // collect receives event
    shared.emit(2)

    val c2=launch {
        println("shared c2")
        shared.collect { println("shared c2 collect ->$it") }
        println("end of shared c2")
    }


    shared.emit(3)

}