
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*


fun main()=runBlocking{

    val numberflow:Flow<Int> = flow{

        for(i in 1..30)
        {
            delay(100)
            println("Emitting $i")
            emit(i)
        }

    }

   numberflow.conflate().collect { value ->
       delay(100)
       println("coll  $value")
   }

}