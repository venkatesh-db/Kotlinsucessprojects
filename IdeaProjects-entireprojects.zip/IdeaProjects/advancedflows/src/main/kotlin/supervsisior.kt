
import kotlinx.coroutines.*
import kotlinx.coroutines.runBlocking


fun main()= runBlocking{

    println("parent starts")

    supervisorScope {

        launch {
         throw RuntimeException("happy man")
            println("child1 starts")
        }

        launch {
            println("child2 starts")
        }
    }

    println("parent ends")

}

