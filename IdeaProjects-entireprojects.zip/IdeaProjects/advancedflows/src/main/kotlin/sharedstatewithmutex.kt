
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

fun main()= runBlocking<Unit> {

    val mutex = Mutex()
    var counter = 0

    val jobs=List(3){

        launch {

            repeat(2) {


                mutex.withLock {
                    counter++
                }

            }
        }
    }

    jobs.forEach { it.join() }

     println("counter=$counter")
}