package org.example

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

fun main() = runBlocking {


    val coldFlow = flow {

        println("Flow started")

        emit("A") // call collect synchronixation
        emit("B")
        emit("C")
        emit(1)
        println("flow completed")

    } .flowOn(Dispatchers.IO)// it will register

    println("rain started")

    // when collect will wait data
   // coldFlow.collect { println("Collector 1: $it") }

    println("rain started1")
   // coldFlow.collect { println("Collector 2: $it") } // gets values again

    println("rain started2")

}



