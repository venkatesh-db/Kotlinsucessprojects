package org.example


import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*

// --- Data Model ---
data class Transaction(
    val id: Int,
    val customer: String,
    val amount: Double,
    val reconciledAmount: Double,
    val status: String
)

// --- Channel + Flow categorization ---
fun categorizeTransactionsFlow(transactions: List<Transaction>) = flow {
    val pendingChannel = Channel<Transaction>(Channel.UNLIMITED)
    val highValueChannel = Channel<Transaction>(Channel.UNLIMITED)
    val mismatchedChannel = Channel<Transaction>(Channel.UNLIMITED)

    coroutineScope {
        // Producer: feed transactions
        launch(Dispatchers.Default) {
            for (t in transactions) {
                pendingChannel.send(t)
                highValueChannel.send(t)
                mismatchedChannel.send(t)
            }
            pendingChannel.close()
            highValueChannel.close()
            mismatchedChannel.close()
        }

        // Consumers: process asynchronously
        val pendingFlow = pendingChannel.consumeAsFlow()
            .filter { it.status == "PENDING" }

        val highValueFlow = highValueChannel.consumeAsFlow()
            .filter { it.amount > 50_000 }

        val mismatchedFlow = mismatchedChannel.consumeAsFlow()
            .filter { it.amount != it.reconciledAmount }

        // Merge results in a single flow
        emit(
            Triple(
                pendingFlow.toList(),
                highValueFlow.toList(),
                mismatchedFlow.toList()
            )
        )
    }
}

// --- Main ---
fun main() = runBlocking {
    // Simulate 1M transactions
    val transactions = (1..1_000_000).map { id ->
        Transaction(
            id = id,
            customer = "Customer$id",
            amount = if (id % 1000 == 0) 100_000.0 else 5000.0,
            reconciledAmount = if (id % 500 == 0) 0.0 else 5000.0,
            status = if (id % 200 == 0) "PENDING" else "SETTLED"
        )
    }

    val startTime = System.currentTimeMillis()

    val (pending, highValue, mismatched) = categorizeTransactionsFlow(transactions)
        .single() // single emission

    val endTime = System.currentTimeMillis()

    println("Pending Settlements: ${pending.size}")
    println("High Value Transactions: ${highValue.size}")
    println("Mismatched Records: ${mismatched.size}")
    println("Execution Time: ${endTime - startTime} ms")
}