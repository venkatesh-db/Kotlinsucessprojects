package com.example.productcatalogservice.controller

import com.example.productcatalogservice.service.ProductService
import com.example.productcatalogservice.model.Product
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping(value = ["/products"])
class ProductController(private val service: ProductService) {

    @PostMapping
    fun create(@RequestBody request: Product): ResponseEntity<Product> {
        val saved=service.createorUpdate(request)
        return ResponseEntity.ok(saved)
    }

    @PutMapping(value = ["/{id}/price"])
    fun updatePrice(@PathVariable id: Long, @RequestParam price: Double): ResponseEntity<Product> {

     val p=   service.findById(id)?:return ResponseEntity.notFound().build()

        p.price=price

        val saved=service.createorUpdate(p)

        return ResponseEntity.ok(saved)
    }

    @GetMapping(value = ["/{id}"])
    fun get(@PathVariable id: Long): ResponseEntity<Product> {

     val p=   service.findById(id)?:return ResponseEntity.notFound().build()
        return ResponseEntity.ok(p)
    }

}