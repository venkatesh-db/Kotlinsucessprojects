package com.example.productcatalogservice.service

import com.example.productcatalogservice.model.Product
import com.example.productcatalogservice.repository.ProductRepository
import org.springframework.data.redis.core.RedisTemplate
import org.springframework.stereotype.Service
import java.time.Instant

@Service
class ProductService(private val repo: ProductRepository,private val redisTemplate : RedisTemplate<String, Any>) {


    private fun priceKey(productId: Long) ="product:price:$productId"

    fun createorUpdate(product: Product): Product {

        product.lastUpdated = Instant.now()

        val saved=repo.save(product)

        redisTemplate.opsForValue().set(priceKey(saved.id!!), saved.price)

        return saved

    }

    fun findById(id: Long): Product? =repo.findById(id).orElse(null)
}